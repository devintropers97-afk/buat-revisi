<!DOCTYPE html>
<html>
<head>
    <title>500 - Server Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container text-center py-5">
        <h1 class="display-1">500</h1>
        <h2>Internal Server Error</h2>
        <p>Something went wrong on our end.</p>
        <a href="<?= url('') ?>" class="btn btn-primary">Go Home</a>
    </div>
</body>
</html>
