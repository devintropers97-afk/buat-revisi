<?php
function send_email($to, $subject, $message) { return true; }
